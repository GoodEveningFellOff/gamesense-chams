# required-materials

You must unzip these materials and place them in your Counter-Strike Global Offensive/csgo/materials/custom_chams folder.
If you do not have the /custom_chams folder in your materials directory then please create it.

If you fail to do this step correctly then you may need to restart csgo after correcting the issue.
Errors will appear as the material not rendering.

Tutorial:
  https://youtu.be/0swCaRlOPKw

**MAKE SURE YOU ARE USING THE LATEST VERSION OF THE SCRIPT**
https://github.com/GoodEveningFellOff/gamesense-chams
